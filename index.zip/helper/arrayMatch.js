module.exports.matchValue = function (array, value){
      for(var i=0; i<array.length; i++) {
          if (array[i] == value) return true;
      }
  }
